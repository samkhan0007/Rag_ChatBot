import streamlit as st
import requests
from datetime import datetime
import json

# ---------------- API URL ---------------- #
API_URL = "http://127.0.0.1:5000"

# ---------------- PAGE CONFIG ---------------- #
st.set_page_config(
    page_title="RAG PDF Chatbot",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ---------------- CUSTOM CSS FOR PROFESSIONAL LOOK ---------------- #
st.markdown("""
    <style>
    /* Main container styling */
    .main {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    
    /* Chat message styling */
    .user-message {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 15px 20px;
        border-radius: 20px;
        border-top-right-radius: 5px;
        margin: 10px 0;
        max-width: 70%;
        float: right;
        clear: both;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    
    .bot-message {
        background: #f0f2f6;
        color: #1e1e2f;
        padding: 15px 20px;
        border-radius: 20px;
        border-top-left-radius: 5px;
        margin: 10px 0;
        max-width: 70%;
        float: left;
        clear: both;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    
    /* Sidebar styling */
    .css-1d391kg {
        background-color: #1e1e2f;
    }
    
    /* Button styling */
    .stButton > button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 10px;
        padding: 10px 20px;
        font-weight: bold;
        transition: transform 0.2s;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    /* File uploader styling */
    .uploadedFile {
        border: 2px dashed #667eea;
        border-radius: 10px;
        padding: 20px;
    }
    
    /* Info box styling */
    .source-box {
        background: #f8f9fa;
        border-left: 4px solid #667eea;
        padding: 10px;
        margin: 10px 0;
        border-radius: 5px;
        font-size: 0.9em;
    }
    
    /* Header styling */
    .chat-header {
        background: white;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 20px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    
    /* Timestamp styling */
    .timestamp {
        font-size: 0.7em;
        color: #666;
        margin-top: 5px;
    }
    
    /* Clearfix for messages */
    .message-container {
        overflow: auto;
        margin-bottom: 20px;
    }
    </style>
""", unsafe_allow_html=True)

# ---------------- SESSION STATE INITIALIZATION ---------------- #
if 'messages' not in st.session_state:
    st.session_state.messages = []
if 'current_pdf' not in st.session_state:
    st.session_state.current_pdf = None
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []

# ---------------- SIDEBAR ---------------- #
with st.sidebar:
    st.markdown("## 🤖 RAG PDF Chatbot")
    st.markdown("---")
    
    # File upload section
    st.markdown("### 📄 Document Upload")
    uploaded_file = st.file_uploader(
        "Upload PDF Document",
        type=["pdf"],
        help="Upload a PDF file to start asking questions"
    )
    
    # Process PDF
    if uploaded_file:
        if st.session_state.current_pdf != uploaded_file.name:
            with st.spinner("Processing PDF..."):
                files = {
                    "file": (
                        uploaded_file.name,
                        uploaded_file,
                        "application/pdf"
                    )
                }
                try:
                    response = requests.post(
                        f"{API_URL}/upload",
                        files=files
                    )
                    if response.status_code == 200:
                        st.session_state.current_pdf = uploaded_file.name
                        st.success("✅ PDF processed successfully!")
                        # Clear chat history when new PDF is uploaded
                        st.session_state.messages = []
                        st.session_state.chat_history = []
                        st.balloons()
                    else:
                        st.error("❌ Failed to process PDF")
                except Exception as e:
                    st.error(f"❌ Error: {str(e)}")
    
    # Display current PDF info
    if st.session_state.current_pdf:
        st.markdown("### 📑 Current Document")
        st.info(f"**{st.session_state.current_pdf}**")
    
    st.markdown("---")
    
    # Controls section
    st.markdown("### 🛠️ Controls")
    
    # Clear chat button
    if st.button("🗑️ Clear Chat", use_container_width=True):
        st.session_state.messages = []
        st.session_state.chat_history = []
        st.rerun()
    
    # Export chat button
    if st.button("💾 Export Chat", use_container_width=True):
        if st.session_state.chat_history:
            chat_export = json.dumps(st.session_state.chat_history, indent=2)
            st.download_button(
                label="📥 Download Chat History",
                data=chat_export,
                file_name=f"chat_history_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json"
            )
        else:
            st.warning("No chat history to export")
    
    st.markdown("---")
    
    # Info section
    st.markdown("### ℹ️ About")
    st.markdown("""
    This chatbot uses **RAG (Retrieval-Augmented Generation)** to answer questions from your PDF documents.
    
    **Features:**
    - 📄 PDF document processing
    - 💬 Conversational interface
    - 🔍 Source references
    - 📊 Chat history export
    """)

# ---------------- MAIN CHAT INTERFACE ---------------- #
st.markdown('<div class="chat-header">', unsafe_allow_html=True)
col1, col2, col3 = st.columns([1, 3, 1])
with col2:
    st.markdown("## 💬 Chat Interface")
    st.markdown("Ask questions about your uploaded PDF document")
st.markdown('</div>', unsafe_allow_html=True)

# ---------------- CHAT HISTORY DISPLAY ---------------- #
chat_container = st.container()

with chat_container:
    if not st.session_state.messages:
        # Welcome message
        st.markdown('<div class="message-container">', unsafe_allow_html=True)
        st.markdown(
            '<div class="bot-message">'
            '👋 Hello! I\'m your RAG PDF Assistant.<br><br>'
            '📌 **Getting Started:**<br>'
            '1️⃣ Upload a PDF document using the sidebar<br>'
            '2️⃣ Once processed, ask me any question about the document<br>'
            '3️⃣ I\'ll provide answers with source references<br><br>'
            '💡 **Tips:**<br>'
            '• Be specific with your questions<br>'
            '• You can ask follow-up questions<br>'
            '• Export your chat history anytime<br>'
            '</div>',
            unsafe_allow_html=True
        )
        st.markdown('</div>', unsafe_allow_html=True)
    else:
        # Display chat history
        for msg in st.session_state.messages:
            st.markdown('<div class="message-container">', unsafe_allow_html=True)
            if msg["role"] == "user":
                st.markdown(
                    f'<div class="user-message">'
                    f'<strong>You:</strong><br>{msg["content"]}<br>'
                    f'<div class="timestamp">{msg["timestamp"]}</div>'
                    f'</div>',
                    unsafe_allow_html=True
                )
            else:
                st.markdown(
                    f'<div class="bot-message">'
                    f'<strong>🤖 Assistant:</strong><br>{msg["content"]}<br>'
                    f'<div class="timestamp">{msg["timestamp"]}</div>'
                    f'</div>',
                    unsafe_allow_html=True
                )
                # Show sources if available
                if msg.get("sources"):
                    with st.expander("📚 View Source References"):
                        for idx, source in enumerate(msg["sources"], 1):
                            if isinstance(source, dict):
                                st.markdown(f'<div class="source-box">📖 **Source {idx}:**<br>{source["content"]}</div>', unsafe_allow_html=True)
                            else:
                                st.markdown(f'<div class="source-box">📖 **Source {idx}:**<br>{source}</div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)

# ---------------- INPUT SECTION ---------------- #
st.markdown("---")

# Check if PDF is uploaded before allowing questions
if not st.session_state.current_pdf:
    st.warning("⚠️ Please upload a PDF document first using the sidebar to start asking questions.")
    st.info("💡 **Tip:** You can upload multiple PDFs, but only the most recent one will be active.")
else:
    # Create input form
    with st.form(key="chat_form", clear_on_submit=True):
        col1, col2 = st.columns([6, 1])
        with col1:
            user_input = st.text_input(
                "Ask your question:",
                placeholder="e.g., What are the main topics discussed in this document?",
                label_visibility="collapsed"
            )
        with col2:
            submit_button = st.form_submit_button("Send 📤", use_container_width=True)
        
        # Process the question
        if submit_button and user_input:
            # Add user message to chat history
            timestamp = datetime.now().strftime("%I:%M %p")
            st.session_state.messages.append({
                "role": "user",
                "content": user_input,
                "timestamp": timestamp
            })
            
            # Save to chat history
            st.session_state.chat_history.append({
                "role": "user",
                "content": user_input,
                "timestamp": timestamp
            })
            
            # Get response from API
            with st.spinner("🤔 Thinking..."):
                try:
                    response = requests.post(
                        f"{API_URL}/chat",
                        json={"query": user_input},
                        timeout=30
                    )
                    
                    if response.status_code == 200:
                        result = response.json()
                        answer = result.get("answer", "Sorry, I couldn't generate an answer.")
                        sources = result.get("sources", [])
                        
                        # Add bot response to chat history
                        bot_timestamp = datetime.now().strftime("%I:%M %p")
                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": answer,
                            "timestamp": bot_timestamp,
                            "sources": sources
                        })
                        
                        # Save to chat history
                        st.session_state.chat_history.append({
                            "role": "assistant",
                            "content": answer,
                            "timestamp": bot_timestamp,
                            "sources": sources
                        })
                    else:
                        error_msg = f"❌ Error: Unable to get response from server (Status: {response.status_code})"
                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": error_msg,
                            "timestamp": datetime.now().strftime("%I:%M %p")
                        })
                        
                except requests.exceptions.Timeout:
                    error_msg = "⏰ Request timeout. Please try again."
                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": error_msg,
                        "timestamp": datetime.now().strftime("%I:%M %p")
                    })
                except Exception as e:
                    error_msg = f"❌ Error: {str(e)}"
                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": error_msg,
                        "timestamp": datetime.now().strftime("%I:%M %p")
                    })
            
            # Rerun to update the chat display
            st.rerun()

# ---------------- FOOTER ---------------- #
st.markdown("---")
st.markdown(
    "<div style='text-align: center; color: #666; font-size: 0.8em;'>"
    "🔒 Your data is processed locally | 💡 Powered by RAG Technology"
    "</div>",
    unsafe_allow_html=True
)