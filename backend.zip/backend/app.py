from flask import Flask, request, jsonify
from flask_cors import CORS
from rag_pipeline import process_pdf, ask_question
import os

# ---------------- FLASK APP ---------------- #

app = Flask(__name__)

CORS(app)

# ---------------- UPLOAD FOLDER ---------------- #

UPLOAD_FOLDER = "../uploads"

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ---------------- HOME ROUTE ---------------- #

@app.route("/")

def home():

    return jsonify({
        "message": "RAG Chatbot Backend Running"
    })

# ---------------- PDF UPLOAD ROUTE ---------------- #

@app.route("/upload", methods=["POST"])

def upload_file():

    if "file" not in request.files:

        return jsonify({
            "error": "No file uploaded"
        })

    file = request.files["file"]

    file_path = os.path.join(
        UPLOAD_FOLDER,
        file.filename
    )

    file.save(file_path)

    # Process PDF
    process_pdf(file_path)

    return jsonify({
        "message": "PDF uploaded and processed successfully"
    })

# ---------------- CHAT ROUTE ---------------- #

@app.route("/chat", methods=["POST"])

def chat():

    data = request.json

    query = data.get("query")

    if not query:

        return jsonify({
            "error": "Query is required"
        })

    response = ask_question(query)

    return jsonify(response)

# ---------------- RUN APP ---------------- #

if __name__ == "__main__":

    app.run(debug=True)