import os
import pickle
import numpy as np

from dotenv import load_dotenv
from pypdf import PdfReader

from transformers import (
    AutoTokenizer,
    AutoModelForSeq2SeqLM
)

from sentence_transformers import SentenceTransformer

import faiss
import torch

# ---------------- LOAD ENV VARIABLES ---------------- #

load_dotenv()

# ---------------- LOAD LOCAL AI MODEL ---------------- #

print("Loading AI model...")

tokenizer = AutoTokenizer.from_pretrained(
    "google/flan-t5-small"
)

model = AutoModelForSeq2SeqLM.from_pretrained(
    "google/flan-t5-small"
)

print("AI model loaded successfully!")

# ---------------- LOAD EMBEDDING MODEL ---------------- #

print("Loading embedding model...")

embedding_model = SentenceTransformer(
    "all-MiniLM-L6-v2"
)

print("Embedding model loaded successfully!")

# ---------------- CREATE VECTOR DB FOLDER ---------------- #

os.makedirs("../vector_db", exist_ok=True)

# ---------------- VECTOR DB PATHS ---------------- #

INDEX_FILE = "../vector_db/faiss_index.bin"

CHUNKS_FILE = "../vector_db/chunks.pkl"

# ---------------- PDF PROCESSING FUNCTION ---------------- #

def process_pdf(file_path):

    # Read PDF
    pdf_reader = PdfReader(file_path)

    text = ""

    for page in pdf_reader.pages:

        page_text = page.extract_text()

        if page_text:
            text += page_text

    # Handle empty PDF
    if not text.strip():

        raise ValueError(
            "No text found in PDF"
        )

    # ---------------- CHUNKING ---------------- #

    chunks = []

    chunk_size = 800

    chunk_overlap = 100

    for i in range(
        0,
        len(text),
        chunk_size - chunk_overlap
    ):

        chunk = text[i:i + chunk_size]

        chunks.append(chunk)

    # ---------------- CREATE EMBEDDINGS ---------------- #

    embeddings = embedding_model.encode(chunks)

    embeddings = np.array(
        embeddings,
        dtype=np.float32
    )

    # ---------------- CREATE FAISS INDEX ---------------- #

    dimension = embeddings.shape[1]

    index = faiss.IndexFlatL2(dimension)

    index.add(embeddings)

    # ---------------- SAVE VECTOR DB ---------------- #

    faiss.write_index(
        index,
        INDEX_FILE
    )

    # Save chunks
    with open(CHUNKS_FILE, "wb") as f:

        pickle.dump(chunks, f)

    print("PDF processed successfully!")

# ---------------- QUESTION ANSWERING ---------------- #

def ask_question(query):

    # ---------------- LOAD VECTOR DB ---------------- #

    index = faiss.read_index(
        INDEX_FILE
    )

    # ---------------- LOAD CHUNKS ---------------- #

    with open(CHUNKS_FILE, "rb") as f:

        chunks = pickle.load(f)

    # ---------------- QUERY EMBEDDING ---------------- #

    query_embedding = embedding_model.encode([query])

    query_embedding = np.array(
        query_embedding,
        dtype=np.float32
    )

    # ---------------- SIMILARITY SEARCH ---------------- #

    distances, indices = index.search(
        query_embedding,
        k=3
    )

    # ---------------- RETRIEVE CHUNKS ---------------- #

    retrieved_chunks = []

    context = ""

    for idx in indices[0]:

        retrieved_chunks.append({
            "source": f"Chunk {idx}",
            "content": chunks[idx]
        })

        context += chunks[idx] + "\n"

    # ---------------- CREATE PROMPT ---------------- #

    prompt = f"""
    You are a helpful AI assistant.

    Answer the question only using the provided context.

    If answer is not available in context,
    say:
    "I could not find the answer in the uploaded document."

    Context:
    {context}

    Question:
    {query}

    Answer:
    """

    # ---------------- TOKENIZE INPUT ---------------- #

    inputs = tokenizer(
        prompt,
        return_tensors="pt",
        truncation=True,
        max_length=512
    )

    # ---------------- GENERATE RESPONSE ---------------- #

    outputs = model.generate(
        **inputs,
        max_new_tokens=100
    )

    answer = tokenizer.decode(
        outputs[0],
        skip_special_tokens=True
    )

    # ---------------- RETURN RESPONSE ---------------- #

    return {
        "answer": answer,
        "sources": retrieved_chunks
    }